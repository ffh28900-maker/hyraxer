import * as THREE from 'three';
import { ModelBuilder } from './ModelBuilder';

export class DamageNumbers {
  private scene: THREE.Scene;
  private digitMaterialsNormal: THREE.SpriteMaterial[] = [];
  private digitMaterialsCrit: THREE.SpriteMaterial[] = [];
  private critBadgeMaterial: THREE.SpriteMaterial;

  private pool: {
    group: THREE.Group;
    digitSprites: THREE.Sprite[];
    critBadgeSprite: THREE.Sprite;
    velocity: THREE.Vector3;
    life: number;
    maxLife: number;
    initialScale: number;
    active: boolean;
  }[] = [];

  constructor(scene: THREE.Scene) {
    this.scene = scene;

    // PERF: the digit atlas (21 canvas draws + GPU texture uploads) is built once per
    // SESSION via the shared material cache, not once per level load/restart. Registering
    // through ModelBuilder.getMaterial also protects the materials (and their canvas
    // textures) from level teardown disposal.
    for (let d = 0; d <= 9; d++) {
      this.digitMaterialsNormal.push(
        ModelBuilder.getMaterial(`dmgnum_v3:d${d}`, () => new THREE.SpriteMaterial({
          map: this.createDigitTexture(`${d}`, false),
          transparent: true,
          depthTest: false,
          depthWrite: false,
        })) as THREE.SpriteMaterial
      );
      this.digitMaterialsCrit.push(
        ModelBuilder.getMaterial(`dmgnum_v3:c${d}`, () => new THREE.SpriteMaterial({
          map: this.createDigitTexture(`${d}`, true),
          transparent: true,
          depthTest: false,
          depthWrite: false,
        })) as THREE.SpriteMaterial
      );
    }

    this.critBadgeMaterial = ModelBuilder.getMaterial('dmgnum_v3:badge', () => new THREE.SpriteMaterial({
      map: this.createCritBadgeTexture(),
      transparent: true,
      depthTest: false,
      depthWrite: false,
    })) as THREE.SpriteMaterial;

    // Pre-allocate pool of 20 DamageNumber Groups
    for (let i = 0; i < 20; i++) {
      const group = new THREE.Group();
      group.visible = false;

      const digitSprites: THREE.Sprite[] = [];
      for (let s = 0; s < 4; s++) {
        const sprite = new THREE.Sprite(this.digitMaterialsNormal[0]);
        sprite.visible = false;
        sprite.frustumCulled = false;
        group.add(sprite);
        digitSprites.push(sprite);
      }

      const critBadgeSprite = new THREE.Sprite(this.critBadgeMaterial);
      critBadgeSprite.visible = false;
      critBadgeSprite.frustumCulled = false;
      critBadgeSprite.scale.set(1.2, 0.6, 1);
      critBadgeSprite.position.set(0, 0.55, 0);
      group.add(critBadgeSprite);

      this.scene.add(group);

      this.pool.push({
        group,
        digitSprites,
        critBadgeSprite,
        velocity: new THREE.Vector3(),
        life: 0,
        maxLife: 1.0,
        initialScale: 1.0,
        active: false,
      });
    }
  }

  private createDigitTexture(digitStr: string, isCrit: boolean): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    if (isCrit) {
      ctx.font = '900 48px system-ui, -apple-system, sans-serif';
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 8;
      ctx.strokeText(digitStr, 32, 32);

      const grad = ctx.createLinearGradient(0, 10, 0, 54);
      grad.addColorStop(0, '#FFFFFF');
      grad.addColorStop(0.3, '#FFEA00');
      grad.addColorStop(1, '#FF1744');
      ctx.fillStyle = grad;
      ctx.fillText(digitStr, 32, 32);
    } else {
      ctx.font = '900 44px system-ui, -apple-system, sans-serif';
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 8;
      ctx.strokeText(digitStr, 32, 32);

      ctx.fillStyle = '#FFEA00';
      ctx.fillText(digitStr, 32, 32);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }

  private createCritBadgeTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '900 32px system-ui, -apple-system, sans-serif';

    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 6;
    ctx.strokeText('💥 CRIT!', 64, 32);

    ctx.fillStyle = '#FF1744';
    ctx.fillText('💥 CRIT!', 64, 32);

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }

  public spawn(position: THREE.Vector3, damage: number, isCrit: boolean = false) {
    if (damage <= 0) return;

    let item = this.pool.find((p) => !p.active);
    if (!item) {
      item = this.pool[0];
    }

    item.active = true;
    item.life = 0.85;
    item.maxLife = 0.85;
    item.initialScale = isCrit ? 1.4 : 1.0;

    item.group.position.copy(position);
    item.group.position.y += 1.0;
    item.group.position.x += (Math.random() - 0.5) * 0.4;
    item.group.position.z += (Math.random() - 0.5) * 0.4;

    item.velocity.set(
      (Math.random() - 0.5) * 1.2,
      2.5 + Math.random() * 1.2,
      (Math.random() - 0.5) * 1.2
    );

    const dmgStr = Math.round(damage).toString();
    const len = dmgStr.length;
    const mats = isCrit ? this.digitMaterialsCrit : this.digitMaterialsNormal;

    for (let i = 0; i < item.digitSprites.length; i++) {
      const sprite = item.digitSprites[i];
      if (i < len) {
        const digit = parseInt(dmgStr[i], 10);
        sprite.material = mats[digit];
        sprite.visible = true;
        const spacing = 0.38;
        const xOffset = (i - (len - 1) / 2) * spacing;
        sprite.position.set(xOffset, 0, 0);
        sprite.scale.set(0.55, 0.55, 1);
      } else {
        sprite.visible = false;
      }
    }

    item.critBadgeSprite.visible = isCrit;
    item.group.visible = true;
  }

  public update(delta: number) {
    for (const item of this.pool) {
      if (!item.active) continue;

      item.life -= delta;

      item.group.position.addScaledVector(item.velocity, delta);
      item.velocity.y -= 4.0 * delta;

      const progress = 1.0 - item.life / item.maxLife; // 0 to 1

      if (progress < 0.2) {
        const pop = progress / 0.2;
        const scale = item.initialScale * (0.5 + 0.6 * Math.sin(pop * Math.PI * 0.5));
        item.group.scale.setScalar(scale);
      } else {
        const fade = (1.0 - progress) / 0.8;
        const scale = item.initialScale * 1.1 * Math.max(0, fade);
        item.group.scale.setScalar(scale);
      }

      if (item.life <= 0) {
        item.active = false;
        item.group.visible = false;
      }
    }
  }

  public clear() {
    for (const item of this.pool) {
      item.active = false;
      item.group.visible = false;
    }
  }
}
