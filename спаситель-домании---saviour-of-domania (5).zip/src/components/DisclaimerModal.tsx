import React from 'react';
import { AlertTriangle, Play, Flame } from 'lucide-react';

interface DisclaimerModalProps {
  onConfirm: () => void;
  onCancel?: () => void;
}

export const DisclaimerModal: React.FC<DisclaimerModalProps> = ({ onConfirm, onCancel }) => {
  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="relative max-w-lg w-full bg-[#0a0506] border-2 border-[#C41E3A] rounded-2xl p-6 md:p-8 text-white shadow-[0_0_60px_rgba(196,30,58,0.5)] flex flex-col items-center animate-in fade-in zoom-in duration-200">
        
        {/* Top Glowing Icon */}
        <div className="w-16 h-16 rounded-full bg-[#C41E3A]/20 border border-[#C41E3A] flex items-center justify-center mb-4 shadow-[0_0_20px_rgba(196,30,58,0.4)]">
          <AlertTriangle className="w-8 h-8 text-[#C41E3A] animate-pulse" />
        </div>

        {/* Title */}
        <div className="text-[10px] uppercase font-mono tracking-[0.4em] text-[#C41E3A] font-bold mb-1">
          ВАЖНОЕ УВЕДОМЛЕНИЕ // DISCLAIMER
        </div>
        <h2 className="text-2xl md:text-3xl font-black uppercase tracking-tight text-white mb-4 text-center">
          ПРЕДУПРЕЖДЕНИЕ И ИНСТРУКЦИЯ
        </h2>

        {/* Main Requested Notice Text Box */}
        <div className="w-full bg-[#18080a] border border-[#C41E3A]/60 rounded-xl p-5 mb-5 shadow-inner relative overflow-hidden">
          <div className="absolute -right-4 -bottom-4 opacity-10 pointer-events-none">
            <Flame className="w-32 h-32 text-[#C41E3A]" />
          </div>
          <p className="text-base md:text-lg font-mono font-black text-red-200 leading-relaxed text-center relative z-10">
            «В этой игре вам нужно отфакать очень стервозного домана и попытаться сдержаться не сжечь его»
          </p>
        </div>

        {/* Subtext explanation */}
        <p className="text-xs font-mono text-gray-400 mb-6 text-center leading-relaxed">
          ⚠️ <span className="text-gray-300 font-bold">Примечание:</span> Это пародийная шуточная игра. Все доманы и персонажи в игре — вымышленные цифровые 3D-модели. Ни одно живое существо не пострадало.
        </p>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 w-full">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onConfirm();
            }}
            className="flex-1 py-4 bg-[#C41E3A] hover:bg-[#d92343] text-white font-mono font-black text-sm uppercase tracking-wider rounded-xl transition shadow-[0_0_25px_rgba(196,30,58,0.7)] flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
          >
            <Play className="w-5 h-5 fill-white" /> ПОНЯТНО, ПОГНАЛИ!
          </button>
          {onCancel && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onCancel();
              }}
              className="py-4 px-6 bg-neutral-900 hover:bg-neutral-800 text-gray-400 hover:text-white font-mono font-bold text-xs uppercase rounded-xl border border-neutral-800 transition"
            >
              ОТМЕНА
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
