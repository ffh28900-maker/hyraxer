// Web Audio API Sound Synthesizer & Dubstep Music Engine for Saviour of Domania

class AudioEngineClass {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private soundVol: number = 0.8;
  private musicVol: number = 0.5;

  private isMusicPlaying: boolean = false;
  private musicInterval: number | null = null;
  private currentTempoBpm: number = 140;
  private beatStep: number = 0;
  private secretRhythmPattern: number[] = [1, 0, 1, 1, 0, 1, 0, 1]; // For Ultra-Doman dodge timing cues

  public init() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  /** Resume an existing context (e.g. after tab switch); never creates one pre-gesture. */
  public resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private bgMp3Audio: HTMLAudioElement | null = null;
  private currentMp3TrackName: string = '';

  private readonly mp3TrackMap: Record<string, string> = {
    'ОСНОВНОЙ ТРЕК': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    'ГЛОТКУ': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    'СМЕРТЬ — НАШЕ ТОПЛИВО': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    'ПЕПЕЛ НА ГУБАХ': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
    'АДСКИЙ ПЬЕДЕСТАЛ': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-16.mp3',
    'СЕКРЕТНЫЙ ТРЕК': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
  };

  public setVolumes(sound: number, music: number) {
    this.soundVol = Math.max(0, Math.min(1, sound));
    this.musicVol = Math.max(0, Math.min(1, music));
    if (this.bgMp3Audio) {
      this.bgMp3Audio.volume = this.musicVol;
      if (this.musicVol <= 0 && !this.bgMp3Audio.paused) {
        this.bgMp3Audio.pause();
      } else if (this.musicVol > 0 && this.isMusicPlaying && this.bgMp3Audio.paused) {
        this.bgMp3Audio.play().catch(() => {});
      }
    }
    if (this.minigameAudio) {
      this.minigameAudio.volume = this.musicVol;
      if (this.musicVol <= 0 && !this.minigameAudio.paused) {
        this.minigameAudio.pause();
      }
    }
  }

  // --- SOUND EFFECTS ---

  public playPistolShot() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    // Metallic Mechanical Snap
    const snap = this.ctx.createOscillator();
    const snapGain = this.ctx.createGain();
    snap.type = 'square';
    snap.frequency.setValueAtTime(1400, now);
    snap.frequency.exponentialRampToValueAtTime(300, now + 0.04);
    snapGain.gain.setValueAtTime(0.5 * this.soundVol, now);
    snapGain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
    snap.connect(snapGain);
    snapGain.connect(this.ctx.destination);
    snap.start(now);
    snap.stop(now + 0.04);

    // Main Gunshot Body
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(950, now);
    osc.frequency.exponentialRampToValueAtTime(90, now + 0.1);
    gain.gain.setValueAtTime(0.6 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.1);

    // Explosive Noise Transient
    this.playNoiseBlast(0.06, 0.4);
  }

  public playCoinToss() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1400, now);
    osc.frequency.exponentialRampToValueAtTime(2400, now + 0.15);

    gain.gain.setValueAtTime(0.3 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.15);
  }

  public playIceShatter() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    // High crystalline glass/ice chime frequency sweep
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(2800, now);
    osc.frequency.exponentialRampToValueAtTime(800, now + 0.18);
    gain.gain.setValueAtTime(0.4 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.18);

    // Crunch noise blast
    this.playNoiseBlast(0.12, 0.3);
  }

  public playCoinRicochet() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(3200, now);
    osc.frequency.exponentialRampToValueAtTime(1800, now + 0.2);

    gain.gain.setValueAtTime(0.2 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.2);
  }

  public playRicochetImpact() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(50, now + 0.06);

    gain.gain.setValueAtTime(0.035 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.06);
  }

  public playShotgun() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    // Sub-bass Thump
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(25, now + 0.35);
    gain.gain.setValueAtTime(0.95 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.35);

    // Dual Noise Blast
    this.playNoiseBlast(0.25, 0.8);
  }

  public playFlashbang(isBlinded: boolean = false) {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    // Sub-bass explosive blast
    const sub = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(240, now);
    sub.frequency.exponentialRampToValueAtTime(25, now + 0.45);
    subGain.gain.setValueAtTime(0.95 * this.soundVol, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
    sub.connect(subGain);
    subGain.connect(this.ctx.destination);
    sub.start(now);
    sub.stop(now + 0.45);

    // Sharp noise burst
    this.playNoiseBlast(0.22, 0.75);

    // High-frequency tinnitus ringing if player is blinded
    if (isBlinded) {
      const ring = this.ctx.createOscillator();
      const ringGain = this.ctx.createGain();
      ring.type = 'sine';
      ring.frequency.setValueAtTime(4200, now);
      ring.frequency.exponentialRampToValueAtTime(3600, now + 2.8);

      ringGain.gain.setValueAtTime(0.35 * this.soundVol, now);
      ringGain.gain.exponentialRampToValueAtTime(0.001, now + 2.8);

      ring.connect(ringGain);
      ringGain.connect(this.ctx.destination);
      ring.start(now);
      ring.stop(now + 2.8);
    }
  }

  public playRifleShot(isBerserk: boolean = false) {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(isBerserk ? 450 : 750, now);
    osc.frequency.exponentialRampToValueAtTime(70, now + 0.08);

    gain.gain.setValueAtTime((isBerserk ? 0.65 : 0.45) * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.08);

    this.playNoiseBlast(0.08, isBerserk ? 0.6 : 0.35);
  }

  public playDash() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(300, now);
    osc.frequency.exponentialRampToValueAtTime(900, now + 0.12);

    gain.gain.setValueAtTime(0.4 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.12);
  }

  private lastChargeSoundTime: number = 0;

  public playPunchCharge(_ratio: number) {
    // Charge sound muted per user request
  }

  public playHvbPunch(chargeRatio: number = 1.0) {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const startFreq = 80 + chargeRatio * 180;
    const endFreq = 25;
    const duration = 0.25 + chargeRatio * 0.25;

    // Heavy sub-bass blast
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(endFreq, now + duration);

    gain.gain.setValueAtTime((0.18 + chargeRatio * 0.1) * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + duration);

    this.playNoiseBlast(0.1 + chargeRatio * 0.08, 0.12 + chargeRatio * 0.1);
  }

  public playGroundPoundSlam() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(25, now + 0.35);

    gain.gain.setValueAtTime(0.9 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.35);
  }

  public playGrappleHook() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1200, now);
    osc.frequency.exponentialRampToValueAtTime(400, now + 0.18);

    gain.gain.setValueAtTime(0.4 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.18);
  }

  public playGrappleRetract() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(400, now);
    osc.frequency.exponentialRampToValueAtTime(1200, now + 0.16);

    gain.gain.setValueAtTime(0.35 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.16);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.16);
  }

  public playHealNanoFluid() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(500, now);
    osc.frequency.exponentialRampToValueAtTime(1200, now + 0.2);

    gain.gain.setValueAtTime(0.4 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.2);
  }

  public playRocketLaunch() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(320, now + 0.15);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.35);

    gain.gain.setValueAtTime(0.6 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.35);

    this.playNoiseBlast(0.25, 0.4);
  }

  public playExplosion() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(100, now);
    osc.frequency.exponentialRampToValueAtTime(20, now + 0.4);

    gain.gain.setValueAtTime(0.9 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.4);

    this.playNoiseBlast(0.4, 0.7);
  }

  public playDemonRoar() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(35, now + 1.2);

    // Add low-frequency modulation for guttural roar
    const lfo = this.ctx.createOscillator();
    lfo.frequency.setValueAtTime(12, now);
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.setValueAtTime(25, now);
    lfo.connect(osc.frequency);
    lfo.start(now);
    lfo.stop(now + 1.2);

    gain.gain.setValueAtTime(1.0 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 1.2);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 1.2);

    this.playNoiseBlast(0.8, 0.85);
  }

  public playLaserShot() {
    if (!this.ctx || this.soundVol <= 0) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1800, now);
    osc.frequency.exponentialRampToValueAtTime(220, now + 0.25);

    gain.gain.setValueAtTime(0.7 * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.25);
  }

  private cachedNoiseBuffer: AudioBuffer | null = null;

  private getNoiseBuffer(): AudioBuffer | null {
    if (!this.ctx) return null;
    if (!this.cachedNoiseBuffer) {
      const bufferSize = Math.floor(this.ctx.sampleRate * 1.0); // 1 second buffer
      this.cachedNoiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = this.cachedNoiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
    }
    return this.cachedNoiseBuffer;
  }

  private playNoiseBlast(duration: number, volume: number, when?: number) {
    if (!this.ctx) return;
    const buffer = this.getNoiseBuffer();
    if (!buffer) return;

    const now = when ?? this.ctx.currentTime;
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1000, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(volume * this.soundVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    noise.start(now);
    noise.stop(now + duration);
  }

  private currentLevelNumber: number = 1;
  public currentTrackName: string = 'ОСНОВНОЙ ТРЕК';

  public getTrackName(levelNumber: number = this.currentLevelNumber, isSecretLevel: boolean = false): string {
    if (isSecretLevel) return 'СЕКРЕТНЫЙ ТРЕК';
    if (levelNumber >= 1 && levelNumber <= 4) return 'ОСНОВНОЙ ТРЕК';
    if (levelNumber >= 5 && levelNumber <= 8) return 'ГЛОТКУ';
    if (levelNumber >= 9 && levelNumber <= 12) return 'СМЕРТЬ — НАШЕ ТОПЛИВО';
    if (levelNumber >= 13 && levelNumber <= 16) return 'ПЕПЕЛ НА ГУБАХ';
    if (levelNumber >= 17) return 'АДСКИЙ ПЬЕДЕСТАЛ';
    return 'ОСНОВНОЙ ТРЕК';
  }

  // --- DUBSTEP / CYBERPUNK MUSIC ENGINE ---

  public startMusic(isBossLevel: boolean = false, isSecretLevel: boolean = false, levelNumber: number = 1) {
    this.init();
    if (this.isMusicPlaying) this.stopMusic();

    this.isMusicPlaying = true;
    this.currentLevelNumber = levelNumber;
    this.beatStep = 0;

    this.currentTrackName = this.getTrackName(levelNumber, isSecretLevel);

    // Stop secret minigame audio stream so moans/groans are NEVER played on standard levels
    this.stopMinigameAudio();

    if (isSecretLevel) {
      // Secret level uses the secret minigame audio stream
      this.startMinigameAudio();
      return;
    }

    // Set BPM for synthesized music tracks based on level theme
    if (levelNumber >= 5 && levelNumber <= 8) {
      this.currentTempoBpm = 148; // "ГЛОТКУ" - Heavy industrial dubstep
    } else if (levelNumber >= 9 && levelNumber <= 12) {
      this.currentTempoBpm = 160; // "СМЕРТЬ — НАШЕ ТОПЛИВО" - High octane speed cyberpunk
    } else if (levelNumber >= 13 && levelNumber <= 16) {
      this.currentTempoBpm = 140; // "ПЕПЕЛ НА ГУБАХ" - Dark doom synth
    } else if (levelNumber >= 17 || isBossLevel) {
      this.currentTempoBpm = 168; // "АДСКИЙ ПЬЕДЕСТАЛ" - Boss apocalyptic thrash metal
    } else {
      this.currentTempoBpm = 138; // "ОСНОВНОЙ ТРЕК" - Cyberpunk synthwave
    }

    // Audio-clock lookahead scheduler for synthetic synth music
    const stepDur = 60 / this.currentTempoBpm / 4; // 16th note duration (sec)
    this.nextNoteTime = (this.ctx ? this.ctx.currentTime : 0) + 0.05;

    this.musicInterval = window.setInterval(() => {
      if (!this.ctx || !this.isMusicPlaying) return;
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      const horizon = this.ctx.currentTime + 0.12;
      while (this.nextNoteTime < horizon) {
        this.tickMusicBeat(isBossLevel, isSecretLevel, this.nextNoteTime);
        this.nextNoteTime += stepDur;
      }
    }, 25);
  }

  private nextNoteTime = 0;

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicInterval !== null) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    if (this.bgMp3Audio) {
      this.bgMp3Audio.pause();
    }
    this.stopMinigameAudio();
  }

  private tickMusicBeat(isBoss: boolean, isSecret: boolean, when?: number) {
    if (!this.ctx || this.musicVol <= 0) return;
    const now = when ?? this.ctx.currentTime;
    const step = this.beatStep % 16;
    this.beatStep++;

    const lvl = this.currentLevelNumber;

    // --- TRACK SPECIFIC RHYTHM & DRUMS ---
    if (lvl >= 1 && lvl <= 4 && !isSecret) {
      // TRACK: "ОСНОВНОЙ ТРЕК" (Cyberpunk Synthwave 138 BPM)
      if (step === 0 || step === 6 || step === 8 || step === 10) {
        this.playKick(now, 145, 35, 0.65 * this.musicVol);
      }
      if (step === 4 || step === 12) {
        this.playNoiseBlast(0.12, 0.42 * this.musicVol, now);
      }
      const synthwaveNotes = [48, 48, 55, 52, 48, 55, 58, 46];
      const leadNotes = [60, 63, 67, 72, 67, 63, 60, 65];
      if (step % 2 === 0) {
        const bassNote = synthwaveNotes[Math.floor(step / 2) % synthwaveNotes.length];
        this.playWobbleBass(now, bassNote, 1600, 5);
      }
      if (step % 4 === 0) {
        const lead = leadNotes[Math.floor(step / 4) % leadNotes.length];
        this.playFastLead(now, lead, 0.14);
      }
    } else if (lvl >= 5 && lvl <= 8) {
      // TRACK: "ГЛОТКУ" (Heavy Industrial Dubstep)
      if (step === 0 || step === 6 || step === 8 || step === 12) {
        this.playKick(now, 160, 32, 0.7 * this.musicVol);
      }
      if (step === 4 || step === 12 || step === 14) {
        this.playNoiseBlast(0.14, 0.45 * this.musicVol, now);
      }
      if (step % 2 === 0) {
        const notes = [43, 43, 50, 46, 43, 48, 52, 41];
        const note = notes[Math.floor(step / 2) % notes.length];
        this.playWobbleBass(now, note, step % 4 === 0 ? 2200 : 750, 7);
      }
    } else if (lvl >= 9 && lvl <= 12) {
      // TRACK: "СМЕРТЬ — НАШЕ ТОПЛИВО" (High-Octane Speed Cyberpunk)
      if (step === 0 || step === 2 || step === 8 || step === 10 || step === 14) {
        this.playKick(now, 180, 45, 0.75 * this.musicVol);
      }
      if (step === 4 || step === 12) {
        this.playNoiseBlast(0.10, 0.5 * this.musicVol, now);
      }
      const speedNotes = [55, 58, 62, 53, 58, 65, 62, 58];
      const note = speedNotes[step % speedNotes.length];
      this.playFastLead(now, note, 0.08);
      if (step % 2 === 0) {
        this.playWobbleBass(now, note - 24, 1400, 4);
      }
    } else if (lvl >= 13 && lvl <= 16) {
      // TRACK: "ПЕПЕЛ НА ГУБАХ" (Dark Atmospheric Doom Synth)
      if (step === 0 || step === 8) {
        this.playKick(now, 120, 28, 0.8 * this.musicVol);
      }
      if (step === 4 || step === 12) {
        this.playNoiseBlast(0.22, 0.4 * this.musicVol, now);
      }
      if (step % 4 === 0) {
        const doomNotes = [36, 36, 39, 41, 36, 34, 39, 43];
        const note = doomNotes[Math.floor(step / 4) % doomNotes.length];
        this.playWobbleBass(now, note, 900, 8);
      }
      if (step % 2 === 1) {
        const arpeggio = [60, 63, 67, 72, 67, 63];
        const arpNote = arpeggio[step % arpeggio.length];
        this.playHauntingArp(now, arpNote);
      }
    } else if (lvl >= 17 || isBoss) {
      // TRACK: "АДСКИЙ ПЬЕДЕСТАЛ" (Apocalyptic Boss Metal Synth)
      if (step === 0 || step === 2 || step === 3 || step === 8 || step === 10 || step === 11) {
        this.playKick(now, 200, 38, 0.85 * this.musicVol);
      }
      if (step === 4 || step === 12 || step === 15) {
        this.playNoiseBlast(0.16, 0.55 * this.musicVol, now);
      }
      const bossNotes = [33, 33, 40, 36, 33, 38, 41, 35];
      const note = bossNotes[Math.floor(step / 2) % bossNotes.length];
      this.playWobbleBass(now, note, step % 4 === 0 ? 3000 : 1200, 10);
      if (step === 0 || step === 8) {
        this.playBossSiren(now);
      }
    } else {
      // Standard Default Fallback
      if (step === 0 || step === 8) {
        this.playKick(now, 140, 35, 0.6 * this.musicVol);
      }
      if (step === 4 || step === 12) {
        this.playNoiseBlast(0.12, 0.4 * this.musicVol, now);
      }
      if (step % 2 === 0) {
        this.playWobbleBass(now, 50, 1800, 5);
      }
    }
  }

  private playKick(now: number, startFreq: number, endFreq: number, volume: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(endFreq, now + 0.1);
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  private playWobbleBass(now: number, note: number, cutoff: number, q: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(note, now);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(cutoff, now);
    filter.Q.setValueAtTime(q, now);

    gain.gain.setValueAtTime(0.35 * this.musicVol, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.14);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.14);
  }

  private playFastLead(now: number, note: number, duration: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(note * 4, now);
    gain.gain.setValueAtTime(0.2 * this.musicVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + duration);
  }

  private playHauntingArp(now: number, note: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(note * 4, now);
    gain.gain.setValueAtTime(0.18 * this.musicVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.25);
  }

  private playBossSiren(now: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(800, now);
    osc.frequency.exponentialRampToValueAtTime(1400, now + 0.35);
    gain.gain.setValueAtTime(0.15 * this.musicVol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.35);
  }

  // --- SECRET MINIGAME AUDIO ---
  private minigameAudio: HTMLAudioElement | null = null;
  private fireBurnNode: AudioNode | null = null;
  private fireBurnGain: GainNode | null = null;

  public ensureMinigameAudioPlaying() {
    this.init();
    if (this.minigameAudio) {
      this.minigameAudio.muted = false;
      this.minigameAudio.volume = Math.max(0, Math.min(1, this.musicVol));
      if (this.minigameAudio.paused && this.musicVol > 0) {
        this.minigameAudio.play().catch(() => {});
      }
    } else {
      this.startMinigameAudio();
    }
  }

  public startMinigameAudio(targetPlaybackRate: number = 1.0) {
    this.init();
    if (this.bgMp3Audio) {
      this.bgMp3Audio.pause();
    }
    if (!this.minigameAudio) {
      // Direct video audio stream URL provided by user
      this.minigameAudio = new Audio('https://media-cdn2.lawlietbot.xyz/media/rule34/4957/aa7b218b740d4eae481a83441aca7e32.mp4');
      this.minigameAudio.loop = true;
    }
    this.minigameAudio.muted = false;
    this.minigameAudio.volume = Math.max(0, Math.min(1, this.musicVol));
    this.minigameAudio.playbackRate = targetPlaybackRate;
    
    if (this.musicVol > 0) {
      const playPromise = this.minigameAudio.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn('Audio play blocked or loading:', err);
          const handleGesture = () => {
            if (this.minigameAudio && this.isMusicPlaying && this.musicVol > 0) {
              this.minigameAudio.volume = Math.max(0, Math.min(1, this.musicVol));
              this.minigameAudio.play().catch(() => {});
            }
            window.removeEventListener('pointerdown', handleGesture);
            window.removeEventListener('keydown', handleGesture);
          };
          window.addEventListener('pointerdown', handleGesture, { once: true });
          window.addEventListener('keydown', handleGesture, { once: true });
        });
      }
    }
  }

  public updateMinigameAudioCps(cps: number) {
    if (this.minigameAudio) {
      // Ускорение в 2 раза за каждые 3 CPS: 2^(cps / 3)
      const targetRate = Math.max(0.5, Math.min(16.0, Math.pow(2.0, cps / 3.0)));
      if (Math.abs(this.minigameAudio.playbackRate - targetRate) > 0.05) {
        this.minigameAudio.playbackRate = targetRate;
      }
      this.minigameAudio.muted = false;
      this.minigameAudio.volume = 1.0;
      if (this.minigameAudio.paused) {
        this.minigameAudio.play().catch(() => {});
      }
    }
  }

  public stopMinigameAudio() {
    if (this.minigameAudio) {
      this.minigameAudio.pause();
      this.minigameAudio.currentTime = 0;
    }
    if (this.bgMp3Audio && this.isMusicPlaying && this.musicVol > 0) {
      this.bgMp3Audio.play().catch(() => {});
    }
    this.stopFireBurnSound();
  }

  public playFireBurnSound() {
    this.init();
    if (!this.ctx || this.soundVol <= 0 || this.fireBurnNode) return;
    const now = this.ctx.currentTime;

    // Create realistic roaring fire crackle noise
    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(450, now);
    filter.Q.setValueAtTime(1.2, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.5 * this.soundVol, now);

    whiteNoise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    whiteNoise.start(now);
    this.fireBurnNode = whiteNoise as any;
    this.fireBurnGain = gain;
  }

  public stopFireBurnSound() {
    if (this.fireBurnNode) {
      try {
        (this.fireBurnNode as any).stop();
      } catch {
        // Ignore
      }
      this.fireBurnNode = null;
      this.fireBurnGain = null;
    }
  }

  public playMinigameThrust(cps: number) {
    this.ensureMinigameAudioPlaying();
    // Synthetic click sounds removed per user request
  }

  public getSecretBeatStatus(): boolean {
    return this.secretRhythmPattern[this.beatStep % this.secretRhythmPattern.length] === 1;
  }
}

export const AudioEngine = new AudioEngineClass();
